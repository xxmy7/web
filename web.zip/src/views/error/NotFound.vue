<template>
    <img class="not-found" src="@/assets/404.gif">
</template>

<script>
export default {

}
</script>


<style scoped>
.not-found {
  height: 100vh;
  width: 100vw;
}
</style>