<template>
  <ContentField>
    地图相关
  </ContentField>
</template>

<script>
import ContentField from "@/components/ContentField";

export default {
  name: "MapIndexView",
  components: {
    ContentField
  },
}
</script>

<style scoped>

</style>