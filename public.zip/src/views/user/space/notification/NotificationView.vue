<template>
  <ContentField>
    通知
  </ContentField>
</template>

<script>
import ContentField from "@/components/ContentField";

export default {
  components:{
    ContentField,
  }
}
</script>

<style scoped>

</style>